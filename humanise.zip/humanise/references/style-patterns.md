# Style Patterns (13-18, 25-26, 29)

Detailed reference for style-level AI writing patterns. Read the compact summary table in SKILL.md first to identify which patterns apply, then consult this file for rewriting guidance.

---

## 13. Em Dash Overuse

**Problem:** LLMs use em dashes (--) more than humans, mimicking "punchy" sales writing. Note: OpenAI's GPT-5.1 has attempted to suppress em dash use, so this tell is weaker in newer ChatGPT output - use in combination with other indicators.

**Before:**
> The term is primarily promoted by Dutch institutions--not by the people themselves. You don't say "Netherlands, Europe" as an address--yet this mislabeling continues--even in official documents.

**After:**
> The term is primarily promoted by Dutch institutions, not by the people themselves. You don't say "Netherlands, Europe" as an address, yet this mislabeling continues in official documents.

---

## 14. Overuse of Boldface

**Problem:** AI chatbots emphasise phrases in boldface mechanically.

**Before:**
> It blends **OKRs (Objectives and Key Results)**, **KPIs (Key Performance Indicators)**, and visual strategy tools such as the **Business Model Canvas (BMC)** and **Balanced Scorecard (BSC)**.

**After:**
> It blends OKRs, KPIs, and visual strategy tools like the Business Model Canvas and Balanced Scorecard.

---

## 15. Inline-Header Vertical Lists

**Problem:** AI outputs lists where items start with bolded headers followed by colons.

**Before:**
> - **User Experience:** The user experience has been significantly improved with a new interface.
> - **Performance:** Performance has been enhanced through optimized algorithms.
> - **Security:** Security has been strengthened with end-to-end encryption.

**After:**
> The update improves the interface, speeds up load times through optimized algorithms, and adds end-to-end encryption.

---

## 16. Title Case in Headings

**Problem:** AI chatbots capitalise all main words in headings.

**Before:**
> ## Strategic Negotiations And Global Partnerships

**After:**
> ## Strategic negotiations and global partnerships

---

## 17. Emojis

**Problem:** AI chatbots often decorate headings or bullet points with emojis.

**Before:**
> The product launches in Q3
> Key Insight: Users prefer simplicity
> Next Steps: Schedule follow-up meeting

**After:**
> The product launches in Q3. User research showed a preference for simplicity. Next step: schedule a follow-up meeting.

---

## 18. Curly Quotation Marks

**Problem:** ChatGPT and DeepSeek use curly quotes ("\u2026") and curly apostrophes instead of straight quotes ("..."). Gemini and Claude typically avoid curly quotes. Note: Word processors and macOS also produce these, so not always AI-specific.

**Before:**
> He said \u201cthe project is on track\u201d but others disagreed.

**After:**
> He said "the project is on track" but others disagreed.

---

## 25. Unusual Use of Tables

**Problem:** AI chatbots sometimes output small, unnecessary tables for data that would be better presented as prose. The table adds formatting overhead without improving readability.

**Before:**
> | Feature | Status |
> |---------|--------|
> | Dark mode | Available |
> | Export | Available |
> | Collaboration | Coming soon |

**After:**
> The app supports dark mode and export. Collaboration features are planned for a future release.

---

## 26. Skipped Heading Levels

**Problem:** AI chatbots jump from one heading level directly to a level two or more below (e.g., H2 to H4), skipping intermediate levels. This violates accessibility standards and creates inconsistent document structure.

**Before:**
> ## Main Section
> #### Subsection Detail

**After:**
> ## Main Section
> ### Subsection Detail

---

## 29. Thematic Breaks Before Headings

**Problem:** AI chatbots frequently insert horizontal rules (`----` or `---`) before each heading, a Markdown artifact carried over from chat output. In published writing this creates unnecessary visual breaks and signals the text was pasted from a chat interface without cleanup.

**Before:**
> The term has roots in 18th-century French textile trade.
>
> ---
>
> ## History
>
> Headwrapping practices date back centuries across multiple cultures.
>
> ---
>
> ## Form and Construction

**After:**
> The term has roots in 18th-century French textile trade.
>
> ## History
>
> Headwrapping practices date back centuries across multiple cultures.
>
> ## Form and Construction

**When to flag:** Horizontal rules appearing mechanically before every heading. Occasional thematic breaks between genuinely distinct content sections are fine - the tell is when they appear before *every* heading like clockwork.
